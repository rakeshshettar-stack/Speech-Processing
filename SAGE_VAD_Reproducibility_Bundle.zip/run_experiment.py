import os, math, json, time, random, zipfile
from dataclasses import dataclass
import numpy as np
import pandas as pd
from scipy.signal import lfilter, butter, stft, istft
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, roc_curve
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neural_network import MLPClassifier
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

SEED=20260815
np.random.seed(SEED); random.seed(SEED); torch.manual_seed(SEED)
torch.set_num_threads(max(1, min(8, os.cpu_count() or 1)))

FS=8000
DUR=2.4
N=int(FS*DUR)
FRAME=160
HOP=80
NFFT=256
NOISES=['babble','car','street','restaurant','airport','exhibition']
OOD_NOISE='construction'
SNRS=[-10,-5,0,5,10,15]
REPS=20
OOD_REPS=20
FEATURE_NAMES=['log_energy','zcr','centroid','bandwidth','rolloff','flatness','flux','b0_250','b250_500','b500_1000','b1000_2000','b2000_3000','b3000_4000']
F=len(FEATURE_NAMES)

# ---------- synthesis ----------
def _smooth_env(n, rng):
    # syllabic envelope with low-rate random modulation
    knots=max(8, int(DUR*7))
    vals=rng.uniform(0.3,1.0,size=knots)
    x=np.linspace(0,1,knots)
    env=np.interp(np.linspace(0,1,n),x,vals)
    b,a=butter(2, 8/(FS/2), btype='low')
    env=lfilter(b,a,env)
    env=np.clip(env,0,1)
    return env

def make_activity_mask(rng):
    mask=np.zeros(N,dtype=np.float32)
    pos=0
    state=0 if rng.random()<0.55 else 1
    while pos<N:
        if state==1:
            dur=rng.uniform(0.18,0.75)
        else:
            dur=rng.uniform(0.08,0.45)
        L=min(N-pos,int(dur*FS))
        mask[pos:pos+L]=state
        pos+=L; state=1-state
    # ensure nontrivial speech amount
    r=mask.mean()
    if r<0.3 or r>0.8:
        return make_activity_mask(rng)
    # soften transitions for waveform multiplication, labels stay binary separately
    return mask

def resonator_coeff(f,bw):
    r=np.exp(-np.pi*bw/FS)
    theta=2*np.pi*f/FS
    a=np.array([1,-2*r*np.cos(theta),r*r])
    b=np.array([1-r])
    return b,a

def synth_speech(rng, mask):
    t=np.arange(N)/FS
    f0=rng.uniform(90,210)
    fmod=rng.uniform(0.8,2.5)
    inst_f0=f0*(1+0.05*np.sin(2*np.pi*fmod*t+rng.uniform(0,2*np.pi)))
    phase=np.cumsum(2*np.pi*inst_f0/FS)
    exc=np.zeros(N)
    for h in range(1,13):
        exc += (1/h)*np.sin(h*phase+rng.uniform(0,2*np.pi))
    exc += 0.12*rng.normal(size=N)  # aspiration/unvoiced component
    env=_smooth_env(N,rng)
    x=exc*env
    # random vowel-like formants
    formant_sets=[(500,1500,2500),(400,1900,2550),(650,1150,2400),(300,2200,3000),(700,1200,2600)]
    formants=formant_sets[rng.integers(0,len(formant_sets))]
    y=x.copy()
    for f,bw in zip(formants,(80,120,160)):
        b,a=resonator_coeff(f,bw)
        y=lfilter(b,a,y)
    y=y/(np.std(y)+1e-8)
    # add fricative high-frequency component on random subregions inside speech
    fr=rng.normal(size=N)
    b,a=butter(2, 1200/(FS/2), btype='high')
    fr=lfilter(b,a,fr)
    fr=fr/(np.std(fr)+1e-8)
    y=0.88*y+0.12*fr
    # fade activity mask boundaries using short convolution
    soft=np.convolve(mask,np.hanning(81)/np.hanning(81).sum(),mode='same')
    y*=soft
    y/=np.max(np.abs(y))+1e-8
    return y.astype(np.float32)

def pink_noise(rng,n):
    white=rng.normal(size=n)
    # simple low-pass shaping for 1/f-ish noise
    return lfilter([0.049922,0.095993,0.050612,-0.004408], [1,-2.494956,2.017265,-0.522189], white)

def make_noise(noise_type,rng):
    t=np.arange(N)/FS
    if noise_type=='car':
        base=pink_noise(rng,N)
        b,a=butter(3, 500/(FS/2), btype='low')
        base=lfilter(b,a,base)
        hum=0.7*np.sin(2*np.pi*rng.uniform(55,95)*t)+0.25*np.sin(2*np.pi*rng.uniform(110,180)*t)
        z=base+hum
    elif noise_type=='babble':
        z=np.zeros(N)
        for _ in range(5):
            m=make_activity_mask(rng)
            z+=synth_speech(rng,m)*rng.uniform(0.4,1.0)
    elif noise_type=='street':
        z=0.7*pink_noise(rng,N)+0.35*rng.normal(size=N)
        # horn/impulses
        for _ in range(rng.integers(3,8)):
            p=rng.integers(0,N-300)
            L=rng.integers(80,300)
            tt=np.arange(L)/FS
            z[p:p+L]+=rng.uniform(1,3)*np.sin(2*np.pi*rng.uniform(350,900)*tt)*np.hanning(L)
    elif noise_type=='restaurant':
        z=np.zeros(N)
        for _ in range(3):
            m=make_activity_mask(rng)
            z+=0.7*synth_speech(rng,m)
        z+=0.35*pink_noise(rng,N)
        for _ in range(rng.integers(5,12)):
            p=rng.integers(0,N-50); L=rng.integers(10,50)
            z[p:p+L]+=rng.uniform(1,3)*np.hanning(L)*rng.choice([-1,1])
    elif noise_type=='airport':
        z=0.65*pink_noise(rng,N)+0.4*rng.normal(size=N)
        z+=0.5*np.sin(2*np.pi*70*t)+0.25*np.sin(2*np.pi*140*t)
        # announcement-like distant speech
        m=make_activity_mask(rng)
        ann=synth_speech(rng,m)
        b,a=butter(3, 1800/(FS/2), btype='low')
        z+=0.35*lfilter(b,a,ann)
    elif noise_type=='exhibition':
        z=np.zeros(N)
        for _ in range(4):
            m=make_activity_mask(rng); z+=0.55*synth_speech(rng,m)
        z+=0.25*rng.normal(size=N)
        # reverb-like delay
        delay=int(rng.uniform(0.025,0.07)*FS)
        z[delay:]+=0.35*z[:-delay]
    elif noise_type=='construction':
        z=0.55*rng.normal(size=N)+0.45*pink_noise(rng,N)
        # hammer/drill transients + tonal drill
        z+=0.25*np.sin(2*np.pi*rng.uniform(700,1300)*t)*(0.5+0.5*np.sin(2*np.pi*5*t))
        for _ in range(rng.integers(8,18)):
            p=rng.integers(0,N-100); L=rng.integers(20,100)
            z[p:p+L]+=rng.uniform(1.5,4.0)*np.exp(-np.linspace(0,6,L))*rng.choice([-1,1])
    else:
        z=rng.normal(size=N)
    z=z-np.mean(z)
    z=z/(np.std(z)+1e-8)
    return z.astype(np.float32)

def mix_at_snr(speech,noise,mask,snr_db):
    active=mask>0.5
    ps=np.mean(speech[active]**2)+1e-12
    pn=np.mean(noise**2)+1e-12
    scale=np.sqrt(ps/(pn*10**(snr_db/10)))
    y=speech+scale*noise
    mx=np.max(np.abs(y))+1e-8
    if mx>0.99: y=0.99*y/mx
    return y.astype(np.float32), float(scale)

# ---------- enhancement + features ----------
def enhance_wiener(y):
    # STFT-based low-percentile noise PSD estimation, no labels used
    f,t,Z=stft(y,fs=FS,window='hann',nperseg=FRAME,noverlap=FRAME-HOP,nfft=NFFT,boundary=None,padded=False)
    P=np.abs(Z)**2
    frame_e=P.mean(axis=0)
    idx=np.argsort(frame_e)[:max(5,int(0.2*len(frame_e)))]
    noise_psd=np.median(P[:,idx],axis=1,keepdims=True)+1e-10
    post=np.maximum(P-noise_psd,0)
    gain=post/(P+1e-10)
    gain=np.clip(gain,0.08,1.0)**0.75
    Ze=Z*gain
    _,x=istft(Ze,fs=FS,window='hann',nperseg=FRAME,noverlap=FRAME-HOP,nfft=NFFT,input_onesided=True,boundary=False)
    if len(x)<len(y): x=np.pad(x,(0,len(y)-len(x)))
    return x[:len(y)].astype(np.float32)

def frame_signal(x):
    nfr=1+(len(x)-FRAME)//HOP
    idx=np.arange(FRAME)[None,:]+HOP*np.arange(nfr)[:,None]
    fr=x[idx]*np.hamming(FRAME)[None,:]
    return fr

def extract_features(x):
    fr=frame_signal(x)
    nfr=fr.shape[0]
    eps=1e-10
    energy=np.mean(fr**2,axis=1)+eps
    loge=np.log10(energy)
    zcr=np.mean((fr[:,:-1]*fr[:,1:])<0,axis=1)
    mag=np.abs(np.fft.rfft(fr,n=NFFT,axis=1))+eps
    p=mag**2
    freqs=np.fft.rfftfreq(NFFT,1/FS)
    psum=p.sum(axis=1)+eps
    centroid=(p*freqs[None,:]).sum(axis=1)/psum
    bandwidth=np.sqrt((p*(freqs[None,:]-centroid[:,None])**2).sum(axis=1)/psum)
    csum=np.cumsum(p,axis=1); target=0.85*psum
    rollidx=(csum>=target[:,None]).argmax(axis=1); rolloff=freqs[rollidx]
    flat=np.exp(np.mean(np.log(mag),axis=1))/(np.mean(mag,axis=1)+eps)
    normmag=mag/(mag.sum(axis=1,keepdims=True)+eps)
    flux=np.zeros(nfr); flux[1:]=np.sqrt(np.sum((normmag[1:]-normmag[:-1])**2,axis=1))
    bands=[(0,250),(250,500),(500,1000),(1000,2000),(2000,3000),(3000,4000)]
    bes=[]
    for lo,hi in bands:
        sel=(freqs>=lo)&(freqs<hi)
        bes.append(np.log10(p[:,sel].mean(axis=1)+eps))
    X=np.column_stack([loge,zcr,centroid,bandwidth,rolloff,flat,flux]+bes)
    return X.astype(np.float32)

def frame_labels(mask):
    fr=frame_signal(mask)
    return (np.mean(fr,axis=1)>=0.5).astype(np.int64)

def estimate_snr_from_features(X):
    e=10**X[:,0]
    floor=np.quantile(e,0.2)+1e-10
    snr=10*np.log10(np.maximum(e-floor,1e-10)/floor)
    return np.clip(snr,-20,30).astype(np.float32)

# ---------- dataset generation ----------
def generate_all(outdir):
    os.makedirs(outdir,exist_ok=True)
    meta_path=os.path.join(outdir,'SynNoisyVAD_metadata.csv')
    npz_path=os.path.join(outdir,'SynNoisyVAD_features.npz')
    if os.path.exists(meta_path) and os.path.exists(npz_path):
        meta=pd.read_csv(meta_path); z=np.load(npz_path)
        return meta,z['X_noisy'],z['X_enhanced'],z['y'],z['clip_id'],z['snr_est']
    rows=[]; all_noisy=[]; all_enh=[]; all_y=[]; all_clip=[]; all_snr_est=[]
    clip_id=0
    combos=[]
    for noise in NOISES:
        for snr in SNRS:
            for r in range(REPS): combos.append((noise,snr,r,False))
    for snr in SNRS:
        for r in range(OOD_REPS): combos.append((OOD_NOISE,snr,r,True))
    t0=time.time()
    for k,(noise,snr,rep,is_ood) in enumerate(combos):
        rng=np.random.default_rng(SEED + k*7919)
        mask=make_activity_mask(rng)
        speech=synth_speech(rng,mask)
        nz=make_noise(noise,rng)
        noisy,scale=mix_at_snr(speech,nz,mask,snr)
        enh=enhance_wiener(noisy)
        Xn=extract_features(noisy); Xe=extract_features(enh); yy=frame_labels(mask)
        m=min(len(yy),len(Xn),len(Xe)); Xn=Xn[:m]; Xe=Xe[:m]; yy=yy[:m]
        snrest=estimate_snr_from_features(Xn)
        all_noisy.append(Xn); all_enh.append(Xe); all_y.append(yy); all_clip.append(np.full(m,clip_id,np.int32)); all_snr_est.append(snrest)
        rows.append(dict(clip_id=clip_id,noise_type=noise,target_snr_db=snr,replicate=rep,is_ood=int(is_ood),speech_ratio=float(mask.mean()),noise_scale=scale,n_frames=m,duration_s=DUR,sample_rate=FS))
        clip_id+=1
        if (k+1)%100==0: print('generated',k+1,'/',len(combos),'elapsed',round(time.time()-t0,1))
    Xn=np.concatenate(all_noisy); Xe=np.concatenate(all_enh); y=np.concatenate(all_y); clip=np.concatenate(all_clip); snrest=np.concatenate(all_snr_est)
    meta=pd.DataFrame(rows)
    meta.to_csv(os.path.join(outdir,'SynNoisyVAD_metadata.csv'),index=False)
    np.savez_compressed(os.path.join(outdir,'SynNoisyVAD_features.npz'),X_noisy=Xn,X_enhanced=Xe,y=y,clip_id=clip,snr_est=snrest,feature_names=np.array(FEATURE_NAMES))
    return meta,Xn,Xe,y,clip,snrest

# ---------- split + sequences ----------
def make_split(meta):
    rng=np.random.default_rng(SEED)
    train=[]; val=[]; test=[]; ood=[]
    for (noise,snr),g in meta.groupby(['noise_type','target_snr_db']):
        ids=g.clip_id.to_numpy().copy(); rng.shuffle(ids)
        if noise==OOD_NOISE:
            ood.extend(ids.tolist()); continue
        n=len(ids); ntr=int(round(n*0.7)); nv=int(round(n*0.15))
        train.extend(ids[:ntr]); val.extend(ids[ntr:ntr+nv]); test.extend(ids[ntr+nv:])
    return np.array(train),np.array(val),np.array(test),np.array(ood)

class SeqDataset(Dataset):
    def __init__(self,Xn,Xe,y,clip,snr_est,clip_ids,scaler_n,scaler_e,seq=64,step=64):
        self.Xn=Xn;self.Xe=Xe;self.y=y;self.clip=clip;self.snr=snr_est;self.seq=seq
        self.scaler_n=scaler_n; self.scaler_e=scaler_e
        self.items=[]
        idsset=set(map(int,clip_ids.tolist()))
        for cid in idsset:
            idx=np.where(clip==cid)[0]
            if len(idx)==0: continue
            for s in range(0,max(1,len(idx)-seq+1),step):
                e=min(s+seq,len(idx))
                if e-s<seq:
                    s=max(0,len(idx)-seq); e=len(idx)
                self.items.append(idx[s:e])
                if e==len(idx): break
    def __len__(self): return len(self.items)
    def __getitem__(self,i):
        idx=self.items[i]
        xn=self.scaler_n.transform(self.Xn[idx]); xe=self.scaler_e.transform(self.Xe[idx])
        yy=self.y[idx].astype(np.float32); ss=self.snr[idx].astype(np.float32)
        return torch.tensor(xn,dtype=torch.float32),torch.tensor(xe,dtype=torch.float32),torch.tensor(ss[:,None],dtype=torch.float32),torch.tensor(yy,dtype=torch.float32),torch.tensor(idx,dtype=torch.long)

class SageVAD(nn.Module):
    def __init__(self,f=F,d=16,heads=2,use_enh=True,use_gate=True,use_trans=True,use_aux=True):
        super().__init__(); self.use_enh=use_enh; self.use_gate=use_gate; self.use_trans=use_trans; self.use_aux=use_aux
        def branch():
            return nn.Sequential(nn.Linear(f,d),nn.LayerNorm(d),nn.GELU())
        self.bn=branch(); self.be=branch()
        self.convn=nn.Sequential(nn.Conv1d(d,d,5,padding=2,groups=d),nn.Conv1d(d,d,1),nn.GELU())
        self.conve=nn.Sequential(nn.Conv1d(d,d,5,padding=2,groups=d),nn.Conv1d(d,d,1),nn.GELU())
        self.gate=nn.Sequential(nn.Linear(1,16),nn.GELU(),nn.Linear(16,d),nn.Sigmoid())
        if use_trans:
            layer=nn.TransformerEncoderLayer(d_model=d,nhead=heads,dim_feedforward=32,dropout=0.1,batch_first=True,activation='gelu',norm_first=True)
            self.trans=nn.TransformerEncoder(layer,num_layers=1)
        self.cls=nn.Linear(d,1)
        self.aux=nn.Sequential(nn.Linear(d,16),nn.GELU(),nn.Linear(16,1))
    def forward(self,xn,xe,snr):
        hn=self.bn(xn); hn=hn+self.convn(hn.transpose(1,2)).transpose(1,2)
        if self.use_enh:
            he=self.be(xe); he=he+self.conve(he.transpose(1,2)).transpose(1,2)
            if self.use_gate:
                g=self.gate(snr/10.0)
                h=g*he+(1-g)*hn
            else:
                h=0.5*(he+hn)
        else:
            h=hn
        if self.use_trans: h=self.trans(h)
        logits=self.cls(h).squeeze(-1)
        aux=self.aux(h.mean(dim=1)).squeeze(-1)
        return logits,aux

def train_model(train_ds,val_ds,config,epochs=10):
    model=SageVAD(**config)
    opt=torch.optim.AdamW(model.parameters(),lr=2e-3,weight_decay=1e-4)
    bce=nn.BCEWithLogitsLoss()
    mse=nn.SmoothL1Loss()
    train_loader=DataLoader(train_ds,batch_size=256,shuffle=True)
    val_loader=DataLoader(val_ds,batch_size=256,shuffle=False)
    hist=[]; best=None; bestf=-1
    for ep in range(epochs):
        model.train(); losses=[]
        for xn,xe,snr,y,idx in train_loader:
            opt.zero_grad(); logit,aux=model(xn,xe,snr)
            loss=bce(logit,y)
            if config.get('use_aux',True):
                target=snr.mean(dim=1).squeeze(-1)/10.0
                loss=loss+0.06*mse(aux,target)
            # temporal smoothness regularizer in stable regions
            p=torch.sigmoid(logit)
            loss=loss+0.01*torch.mean(torch.abs(p[:,1:]-p[:,:-1]))
            loss.backward(); nn.utils.clip_grad_norm_(model.parameters(),5.0); opt.step(); losses.append(loss.item())
        # validation f1 aggregate using sequence predictions
        model.eval(); probs=[]; ys=[]
        with torch.no_grad():
            for xn,xe,snr,y,idx in val_loader:
                logit,_=model(xn,xe,snr); probs.append(torch.sigmoid(logit).cpu().numpy().ravel()); ys.append(y.numpy().ravel())
        pr=np.concatenate(probs); yy=np.concatenate(ys); pred=(pr>=0.5).astype(int); vf=f1_score(yy,pred)
        hist.append((ep+1,float(np.mean(losses)),float(vf)))
        if vf>bestf:
            bestf=vf; best={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    model.load_state_dict(best)
    return model,hist

def predict_frames(model,ds,total_len):
    loader=DataLoader(ds,batch_size=256,shuffle=False)
    sums=np.zeros(total_len,dtype=np.float64); counts=np.zeros(total_len,dtype=np.float64)
    model.eval()
    t0=time.perf_counter(); nseq=0
    with torch.no_grad():
        for xn,xe,snr,y,idx in loader:
            logit,_=model(xn,xe,snr); p=torch.sigmoid(logit).cpu().numpy(); ids=idx.numpy(); nseq+=len(ids)
            for b in range(len(ids)):
                sums[ids[b]]+=p[b]; counts[ids[b]]+=1
    elapsed=time.perf_counter()-t0
    mask=counts>0; out=np.zeros(total_len); out[mask]=sums[mask]/counts[mask]
    return out,mask,elapsed,nseq

def metrics(y,p,thr=0.5):
    pred=(p>=thr).astype(int)
    return dict(accuracy=accuracy_score(y,pred),precision=precision_score(y,pred,zero_division=0),recall=recall_score(y,pred,zero_division=0),f1=f1_score(y,pred,zero_division=0),auroc=roc_auc_score(y,p),far=np.mean((pred==1)&(y==0))/max(np.mean(y==0),1e-12),miss_rate=np.mean((pred==0)&(y==1))/max(np.mean(y==1),1e-12))

def bootstrap_ci(y,p,metric='f1',B=100):
    rng=np.random.default_rng(SEED+99); n=len(y); vals=[]
    for _ in range(B):
        idx=rng.integers(0,n,size=n)
        if metric=='f1': vals.append(f1_score(y[idx],(p[idx]>=0.5).astype(int),zero_division=0))
        else: vals.append(accuracy_score(y[idx],(p[idx]>=0.5).astype(int)))
    return np.quantile(vals,[0.025,0.975]).tolist()

def main():
    outdir='/mnt/data/research_sad/data'
    os.makedirs(outdir,exist_ok=True)
    meta,Xn,Xe,y,clip,snrest=generate_all(outdir)
    train_ids,val_ids,test_ids,ood_ids=make_split(meta)
    # scaling train frames only
    trmask=np.isin(clip,train_ids)
    scaler_n=StandardScaler().fit(Xn[trmask]); scaler_e=StandardScaler().fit(Xe[trmask])
    train_ds=SeqDataset(Xn,Xe,y,clip,snrest,train_ids,scaler_n,scaler_e)
    val_ds=SeqDataset(Xn,Xe,y,clip,snrest,val_ids,scaler_n,scaler_e)
    test_ds=SeqDataset(Xn,Xe,y,clip,snrest,test_ids,scaler_n,scaler_e)
    ood_ds=SeqDataset(Xn,Xe,y,clip,snrest,ood_ids,scaler_n,scaler_e)
    print('seq sizes',len(train_ds),len(val_ds),len(test_ds),len(ood_ds))

    results={}; models={}; histories={}
    configs={
      'SAGE-VAD':dict(f=F,d=16,heads=2,use_enh=True,use_gate=True,use_trans=True,use_aux=True),
      'No enhancement branch':dict(f=F,d=16,heads=2,use_enh=False,use_gate=False,use_trans=True,use_aux=True),
      'Fixed fusion (no gate)':dict(f=F,d=16,heads=2,use_enh=True,use_gate=False,use_trans=True,use_aux=True),
      'No Transformer':dict(f=F,d=16,heads=2,use_enh=True,use_gate=True,use_trans=False,use_aux=True),
      'No auxiliary SNR loss':dict(f=F,d=16,heads=2,use_enh=True,use_gate=True,use_trans=True,use_aux=False),
    }
    for name,cfg in configs.items():
        print('training',name)
        model,hist=train_model(train_ds,val_ds,cfg,epochs=5 if name=='SAGE-VAD' else 2)
        models[name]=model; histories[name]=hist
        p,mask,elapsed,nseq=predict_frames(model,test_ds,len(y)); tm=mask & np.isin(clip,test_ids)
        po,masko,el2,nseqo=predict_frames(model,ood_ds,len(y)); om=masko & np.isin(clip,ood_ids)
        results[name]={'seen':metrics(y[tm],p[tm]),'ood':metrics(y[om],po[om]),'runtime_seen_s':elapsed,'nseq_seen':nseq,'params':sum(v.numel() for v in model.parameters())}
        if name=='SAGE-VAD':
            np.savez('/mnt/data/research_sad/sage_predictions.npz',p_seen=p,mask_seen=tm,p_ood=po,mask_ood=om)
    # frame baselines on noisy features
    tr=np.isin(clip,train_ids); va=np.isin(clip,val_ids); te=np.isin(clip,test_ids); oo=np.isin(clip,ood_ids)
    # energy threshold optimize val f1
    vals=Xn[va,0]; yyv=y[va]; candidates=np.quantile(vals,np.linspace(.05,.95,100))
    bestthr=max(candidates,key=lambda th:f1_score(yyv,(vals>=th).astype(int)))
    for splitmask,label in [(te,'seen'),(oo,'ood')]:
        # map log-energy via sigmoid-ish for auroc; monotonic raw okay normalize
        pp=(Xn[splitmask,0]-Xn[splitmask,0].min())/(np.ptp(Xn[splitmask,0])+1e-8)
        pred=(Xn[splitmask,0]>=bestthr).astype(int)
        m=metrics(y[splitmask],pp,thr=(bestthr-Xn[splitmask,0].min())/(np.ptp(Xn[splitmask,0])+1e-8))
        results.setdefault('Energy threshold',{})[label]=m
    results['Energy threshold']['threshold_logE']=float(bestthr); results['Energy threshold']['params']=1

    # train subset for classical baselines to keep manageable, but clip-stratified frames
    rng=np.random.default_rng(SEED)
    tri=np.where(tr)[0]; maxn=100000
    if len(tri)>maxn: tri=rng.choice(tri,maxn,replace=False)
    for name,clf in [
        ('Logistic regression',make_pipeline(StandardScaler(),LogisticRegression(max_iter=300,class_weight='balanced',random_state=SEED)))
    ]:
        print('fit',name); clf.fit(Xn[tri],y[tri])
        results[name]={}
        for splitmask,label in [(te,'seen'),(oo,'ood')]:
            pp=clf.predict_proba(Xn[splitmask])[:,1]
            results[name][label]=metrics(y[splitmask],pp)
        results[name]['params']=F+1

    # detailed proposed metrics and CIs
    pred=np.load('/mnt/data/research_sad/sage_predictions.npz')
    p=pred['p_seen']; tm=pred['mask_seen']; po=pred['p_ood']; om=pred['mask_ood']
    results['SAGE-VAD']['seen_f1_ci95']=bootstrap_ci(y[tm],p[tm],'f1')
    results['SAGE-VAD']['seen_acc_ci95']=bootstrap_ci(y[tm],p[tm],'acc')
    results['SAGE-VAD']['ood_f1_ci95']=bootstrap_ci(y[om],po[om],'f1')
    # per SNR/noise on seen
    detailed=[]
    for cid in test_ids:
        idx=np.where((clip==cid)&tm)[0]
        if len(idx)==0: continue
        row=meta.loc[meta.clip_id==cid].iloc[0]
        mm=metrics(y[idx],p[idx])
        detailed.append({'clip_id':int(cid),'noise_type':row.noise_type,'snr_db':int(row.target_snr_db),**mm})
    det=pd.DataFrame(detailed); det.to_csv('/mnt/data/research_sad/detailed_seen_metrics.csv',index=False)
    # train curves
    for name,h in histories.items():
        pd.DataFrame(h,columns=['epoch','loss','val_f1']).to_csv('/mnt/data/research_sad/'+name.replace(' ','_').replace('/','_')+'_history.csv',index=False)
    # save results
    with open('/mnt/data/research_sad/results.json','w') as f: json.dump(results,f,indent=2)
    # save split ids and data description
    with open('/mnt/data/research_sad/data/splits.json','w') as f: json.dump({'train':train_ids.tolist(),'val':val_ids.tolist(),'test':test_ids.tolist(),'ood':ood_ids.tolist()},f)
    print(json.dumps(results,indent=2))

if __name__=='__main__': main()
