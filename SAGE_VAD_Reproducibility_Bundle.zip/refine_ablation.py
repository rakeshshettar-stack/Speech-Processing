import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0,'/mnt/data/research_sad')
import run_experiment as r
from sklearn.preprocessing import StandardScaler
meta=pd.read_csv('/mnt/data/research_sad/data/SynNoisyVAD_metadata.csv'); z=np.load('/mnt/data/research_sad/data/SynNoisyVAD_features.npz')
Xn=z['X_noisy']; Xe=z['X_enhanced']; y=z['y']; clip=z['clip_id']; snr=z['snr_est']
tr,va,te,oo=r.make_split(meta); trmask=np.isin(clip,tr)
sn=StandardScaler().fit(Xn[trmask]); se=StandardScaler().fit(Xe[trmask])
train=r.SeqDataset(Xn,Xe,y,clip,snr,tr,sn,se,seq=64,step=64); val=r.SeqDataset(Xn,Xe,y,clip,snr,va,sn,se,seq=64,step=64); test=r.SeqDataset(Xn,Xe,y,clip,snr,te,sn,se,seq=64,step=64); ood=r.SeqDataset(Xn,Xe,y,clip,snr,oo,sn,se,seq=64,step=64)
configs={
 'No enhancement branch':dict(f=r.F,d=24,heads=4,use_enh=False,use_gate=False,use_trans=True,use_aux=True),
 'Fixed fusion (no gate)':dict(f=r.F,d=24,heads=4,use_enh=True,use_gate=False,use_trans=True,use_aux=True),
 'No Transformer':dict(f=r.F,d=24,heads=4,use_enh=True,use_gate=True,use_trans=False,use_aux=True),
 'No auxiliary SNR loss':dict(f=r.F,d=24,heads=4,use_enh=True,use_gate=True,use_trans=True,use_aux=False),
}
which=os.environ.get('WHICH','A')
names=list(configs)[:2] if which=='A' else list(configs)[2:]
out={}
for name in names:
 print('training',name,flush=True)
 model,hist=r.train_model(train,val,configs[name],epochs=8)
 p,mask,elapsed,nseq=r.predict_frames(model,test,len(y)); tm=mask & np.isin(clip,te)
 po,mo,el2,nseqo=r.predict_frames(model,ood,len(y)); om=mo & np.isin(clip,oo)
 out[name]={'seen':r.metrics(y[tm],p[tm]),'ood':r.metrics(y[om],po[om]),'params':sum(v.numel() for v in model.parameters()),'runtime_seen_s':elapsed,'history':hist}
 print(name,json.dumps(out[name],indent=2),flush=True)
with open('/mnt/data/research_sad/refined_ablation_'+which+'.json','w') as f: json.dump(out,f,indent=2)
