import os,json, numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, confusion_matrix
out='/mnt/data/research_sad/figures'; os.makedirs(out,exist_ok=True)
plt.rcParams.update({'font.size':10,'font.family':'DejaVu Serif'})
# 1 architecture schematic
fig,ax=plt.subplots(figsize=(11,4.5)); ax.axis('off')
boxes=[
 (0.02,0.62,0.13,0.18,'Noisy waveform\n8 kHz'),
 (0.19,0.70,0.14,0.15,'Acoustic features\n13-D'),
 (0.19,0.42,0.14,0.15,'Wiener enhancement\n+ 13-D features'),
 (0.38,0.70,0.14,0.15,'Depthwise temporal\nconvolution'),
 (0.38,0.42,0.14,0.15,'Depthwise temporal\nconvolution'),
 (0.57,0.56,0.14,0.18,'SNR-aware\ngated fusion'),
 (0.76,0.56,0.12,0.18,'Transformer\nencoder'),
 (0.91,0.56,0.08,0.18,'Frame\nposterior')]
for x,y,w,h,t in boxes:
    r=plt.Rectangle((x,y),w,h,fill=False,lw=1.5); ax.add_patch(r); ax.text(x+w/2,y+h/2,t,ha='center',va='center')
# arrows
def ar(x1,y1,x2,y2): ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='->',lw=1.3))
ar(.15,.71,.19,.775); ar(.15,.68,.19,.495); ar(.33,.775,.38,.775); ar(.33,.495,.38,.495); ar(.52,.775,.57,.65); ar(.52,.495,.57,.65); ar(.71,.65,.76,.65); ar(.88,.65,.91,.65)
ax.text(.585,.37,'Auxiliary SNR regression loss',ha='center',va='center',fontsize=9)
ar(.64,.56,.62,.43)
ax.text(.5,.93,'SAGE-VAD: SNR-Adaptive Gated Enhancement Voice Activity Detector',ha='center',va='center',fontsize=13,fontweight='bold')
fig.tight_layout(); fig.savefig(out+'/fig1_architecture.png',dpi=220,bbox_inches='tight'); plt.close(fig)

# 2 dataset distribution heatmap
meta=pd.read_csv('/mnt/data/research_sad/data/SynNoisyVAD_metadata.csv')
p=meta[meta.noise_type!='construction'].pivot_table(index='noise_type',columns='target_snr_db',values='clip_id',aggfunc='count')
fig,ax=plt.subplots(figsize=(8.5,4.5)); im=ax.imshow(p.values,aspect='auto')
ax.set_xticks(range(len(p.columns)),p.columns); ax.set_yticks(range(len(p.index)),p.index); ax.set_xlabel('Target SNR (dB)'); ax.set_ylabel('Noise type'); ax.set_title('SynNoisyVAD clip distribution (seen conditions)')
for i in range(p.shape[0]):
 for j in range(p.shape[1]): ax.text(j,i,int(p.values[i,j]),ha='center',va='center',fontsize=9)
fig.colorbar(im,ax=ax,label='Number of clips'); fig.tight_layout(); fig.savefig(out+'/fig2_dataset_distribution.png',dpi=220); plt.close(fig)

# 3 F1 vs SNR models
m=pd.read_csv('/mnt/data/research_sad/per_snr_model_metrics.csv')
fig,ax=plt.subplots(figsize=(8.5,5))
for model,g in m.groupby('model'):
 g=g.sort_values('snr_db'); ax.plot(g.snr_db,g.f1*100,marker='o',label=model)
ax.set_xlabel('SNR (dB)'); ax.set_ylabel('F1-score (%)'); ax.set_title('F1-score across noise severity'); ax.grid(True,alpha=.25); ax.legend(); ax.set_ylim(65,100)
fig.tight_layout(); fig.savefig(out+'/fig3_f1_vs_snr.png',dpi=220); plt.close(fig)

# 4 noise performance
nd=pd.read_csv('/mnt/data/research_sad/refined_detailed_seen_metrics.csv').groupby('noise_type')[['accuracy','f1','auroc']].mean().sort_values('f1')*100
fig,ax=plt.subplots(figsize=(8.8,5)); x=np.arange(len(nd)); w=.26
for k,col in enumerate(['accuracy','f1','auroc']): ax.bar(x+(k-1)*w,nd[col].values,width=w,label=col.upper())
ax.set_xticks(x,nd.index,rotation=25,ha='right'); ax.set_ylabel('Score (%)'); ax.set_title('SAGE-VAD performance by noise type'); ax.set_ylim(75,101); ax.legend(); ax.grid(axis='y',alpha=.2)
fig.tight_layout(); fig.savefig(out+'/fig4_noise_performance.png',dpi=220); plt.close(fig)

# 5 ROC
z=np.load('/mnt/data/research_sad/comparison_predictions.npz'); y=z['y']; ps=z['p_sage']; pl=z['p_logistic']
fig,ax=plt.subplots(figsize=(6.4,5.4))
for label,pred in [('SAGE-VAD',ps),('Logistic regression',pl)]:
 fpr,tpr,_=roc_curve(y,pred); ax.plot(fpr,tpr,label=label)
ax.plot([0,1],[0,1],'--',linewidth=1); ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate'); ax.set_title('ROC on held-out seen-noise test frames'); ax.grid(True,alpha=.2); ax.legend(loc='lower right')
fig.tight_layout(); fig.savefig(out+'/fig5_roc.png',dpi=220); plt.close(fig)

# 6 confusion matrix
cm=confusion_matrix(y,(ps>=.5).astype(int)); cmn=cm/cm.sum(axis=1,keepdims=True)
fig,ax=plt.subplots(figsize=(5.6,4.8)); im=ax.imshow(cmn)
ax.set_xticks([0,1],['Non-speech','Speech']); ax.set_yticks([0,1],['Non-speech','Speech']); ax.set_xlabel('Predicted'); ax.set_ylabel('True'); ax.set_title('Normalized confusion matrix: SAGE-VAD')
for i in range(2):
 for j in range(2): ax.text(j,i,f'{cm[i,j]:,}\n{cmn[i,j]*100:.1f}%',ha='center',va='center')
fig.colorbar(im,ax=ax); fig.tight_layout(); fig.savefig(out+'/fig6_confusion_matrix.png',dpi=220); plt.close(fig)

# 7 ablation
full=json.load(open('/mnt/data/research_sad/refined_full.json'))
a={}
for f in ['/mnt/data/research_sad/refined_ablation_A.json','/mnt/data/research_sad/refined_ablation_B.json']: a.update(json.load(open(f)))
vals={'Full SAGE-VAD':full['seen']['f1']}
for k,v in a.items(): vals[k]=v['seen']['f1']
ser=pd.Series(vals).sort_values()
fig,ax=plt.subplots(figsize=(8.7,5.2)); bars=ax.barh(ser.index,ser.values*100); ax.set_xlabel('F1-score (%)'); ax.set_title('Ablation study on held-out test set'); ax.set_xlim(88,96)
for b,v in zip(bars,ser.values): ax.text(v*100+.08,b.get_y()+b.get_height()/2,f'{v*100:.2f}',va='center',fontsize=9)
ax.grid(axis='x',alpha=.2); fig.tight_layout(); fig.savefig(out+'/fig7_ablation.png',dpi=220); plt.close(fig)

# 8 training curve
h=pd.DataFrame(full['history'],columns=['epoch','loss','val_f1'])
fig,ax=plt.subplots(figsize=(8.3,4.8)); ax.plot(h.epoch,h.val_f1*100,marker='o',label='Validation F1'); ax.set_xlabel('Epoch'); ax.set_ylabel('Validation F1 (%)'); ax.set_title('Training convergence of SAGE-VAD'); ax.grid(True,alpha=.2)
ax2=ax.twinx(); ax2.plot(h.epoch,h.loss,marker='s',label='Training loss'); ax2.set_ylabel('Training loss')
lines=ax.get_lines()+ax2.get_lines(); ax.legend(lines,[l.get_label() for l in lines],loc='center right')
fig.tight_layout(); fig.savefig(out+'/fig8_training_curve.png',dpi=220); plt.close(fig)

print('created',sorted(os.listdir(out)))
