import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0,'/mnt/data/research_sad')
import run_experiment as r
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import f1_score
meta=pd.read_csv('/mnt/data/research_sad/data/SynNoisyVAD_metadata.csv'); z=np.load('/mnt/data/research_sad/data/SynNoisyVAD_features.npz')
Xn=z['X_noisy']; Xe=z['X_enhanced']; y=z['y']; clip=z['clip_id']; snr=z['snr_est']
tr,va,te,oo=r.make_split(meta)
trmask=np.isin(clip,tr)
sn=StandardScaler().fit(Xn[trmask]); se=StandardScaler().fit(Xe[trmask])
train=r.SeqDataset(Xn,Xe,y,clip,snr,tr,sn,se,seq=64,step=64); val=r.SeqDataset(Xn,Xe,y,clip,snr,va,sn,se,seq=64,step=64); test=r.SeqDataset(Xn,Xe,y,clip,snr,te,sn,se,seq=64,step=64); ood=r.SeqDataset(Xn,Xe,y,clip,snr,oo,sn,se,seq=64,step=64)
for d,heads,ep in [(24,4,10)]:
 print('training refined',d,ep,flush=True)
 model,hist=r.train_model(train,val,dict(f=r.F,d=d,heads=heads,use_enh=True,use_gate=True,use_trans=True,use_aux=True),epochs=ep)
 p,mask,elapsed,nseq=r.predict_frames(model,test,len(y)); tm=mask & np.isin(clip,te)
 po,mo,el2,nseqo=r.predict_frames(model,ood,len(y)); om=mo & np.isin(clip,oo)
 out={'seen':r.metrics(y[tm],p[tm]),'ood':r.metrics(y[om],po[om]),'params':sum(v.numel() for v in model.parameters()),'runtime_seen_s':elapsed,'history':hist,'seen_f1_ci95':r.bootstrap_ci(y[tm],p[tm],'f1',B=100),'seen_acc_ci95':r.bootstrap_ci(y[tm],p[tm],'acc',B=100)}
 print(json.dumps(out,indent=2),flush=True)
 np.savez('/mnt/data/research_sad/sage_refined_predictions.npz',p_seen=p,mask_seen=tm,p_ood=po,mask_ood=om)
 with open('/mnt/data/research_sad/refined_full.json','w') as f: json.dump(out,f,indent=2)
 pd.DataFrame(hist,columns=['epoch','loss','val_f1']).to_csv('/mnt/data/research_sad/refined_history.csv',index=False)
